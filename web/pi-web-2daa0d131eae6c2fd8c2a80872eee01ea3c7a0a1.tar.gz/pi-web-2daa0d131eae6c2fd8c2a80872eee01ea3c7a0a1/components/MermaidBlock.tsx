"use client";

import { memo, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { SyntaxHighlighterProps } from "react-syntax-highlighter";
import renderSyntaxNode from "react-syntax-highlighter/dist/esm/create-element";
import SyntaxHighlighter from "react-syntax-highlighter/dist/esm/prism-light";
import { vs } from "react-syntax-highlighter/dist/cjs/styles/prism";
import { vscDarkPlus } from "react-syntax-highlighter/dist/cjs/styles/prism";
import { useTheme } from "@/hooks/useTheme";
import { useI18n } from "@/hooks/useI18n";
import { usePrismLanguages } from "@/hooks/usePrismLanguages";
import { copyText } from "@/lib/clipboard";
import { takeHighlightBudget, waitForHighlight } from "@/lib/highlight-queue";
import { prismLanguagesLoaded } from "@/lib/prism-languages";

interface MermaidBlockProps {
  code: string;
  isStreaming?: boolean;
  defaultPreview?: boolean;
}

const ZOOM_STEP = 0.25;
const ZOOM_MIN = 0.5;
const ZOOM_MAX = 3;

export function downloadSvgFile(xml: string, filename: string): void {
  const url = URL.createObjectURL(new Blob([xml], { type: "image/svg+xml;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

export function downloadMermaidSvg(svg: SVGSVGElement): void {
  // Mermaid's HTML serialization can leave void tags such as <br> unclosed.
  downloadSvgFile(new XMLSerializer().serializeToString(svg), "mermaid-diagram.svg");
}

type RenderState =
  | { key: string; status: "loading" }
  | { key: string; status: "error" }
  | { key: string; status: "ready"; svg: string };

export function MermaidBlock({ code, isStreaming, defaultPreview = false }: MermaidBlockProps) {
  const { isDark } = useTheme();
  const { t } = useI18n();
  const [showPreview, setShowPreview] = useState(defaultPreview);
  const [renderState, setRenderState] = useState<RenderState | null>(null);
  const [zoomOpen, setZoomOpen] = useState(false);
  const previewRef = useRef<HTMLButtonElement>(null);
  const currentKey = `${isDark ? "dark" : "light"}\n${code}`;
  const previewVisible = showPreview && !isStreaming;

  useEffect(() => {
    if (!previewVisible) return;

    let cancelled = false;
    setRenderState({ key: currentKey, status: "loading" });

    const render = async () => {
      const { default: mermaid } = await import("mermaid");
      mermaid.initialize({
        startOnLoad: false,
        securityLevel: "strict",
        suppressErrorRendering: true,
        theme: isDark ? "dark" : "default",
      });

      const parsed = await mermaid.parse(code, { suppressErrors: true });
      if (!parsed) throw new Error("Invalid Mermaid diagram");

      const id =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? `mermaid-${crypto.randomUUID()}`
          : `mermaid-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const result = await mermaid.render(id, code);
      if (!cancelled) {
        setRenderState({ key: currentKey, status: "ready", svg: result.svg });
      }
    };

    render().catch(() => {
      if (!cancelled) setRenderState({ key: currentKey, status: "error" });
    });

    return () => {
      cancelled = true;
    };
  }, [code, currentKey, isDark, previewVisible]);

  const previewButton = useMemo(() => (
    <PreviewToggleButton
      isStreaming={isStreaming}
      previewVisible={previewVisible}
      onToggle={() => setShowPreview((v) => !v)}
      title={previewVisible ? t("i18n.showMermaidSource") : t("i18n.previewMermaid")}
    />
  ), [isStreaming, previewVisible, t]);

  if (!previewVisible) {
    return <CodeBlock code={code} lang="mermaid" headerAction={previewButton} isStreaming={isStreaming} />;
  }

  const body = renderState?.key === currentKey && renderState.status === "error" ? (
      <div className="mermaid-block mermaid-block-error">{t("i18n.invalidMermaid")}</div>
    ) : renderState?.key !== currentKey || renderState.status !== "ready" ? (
      <div className="mermaid-block mermaid-block-loading" aria-label={t("i18n.renderingMermaid")} />
    ) : (
      <>
        {!zoomOpen && (
          <button
            ref={previewRef}
            type="button"
            className="mermaid-block mermaid-preview-button"
            title={t("i18n.openMermaidViewer")}
            aria-label={t("i18n.openMermaidViewer")}
            onClick={() => setZoomOpen(true)}
            dangerouslySetInnerHTML={{ __html: renderState.svg }}
          />
        )}
        {zoomOpen && (
          <DiagramZoomDialog title={t("i18n.mermaidDiagram")} label={t("i18n.mermaidViewer")} onClose={() => setZoomOpen(false)}>
            <div dangerouslySetInnerHTML={{ __html: renderState.svg }} />
          </DiagramZoomDialog>
        )}
      </>
    );

  return (
    <PreviewFrame
      lang="mermaid"
      actions={
        <>
          {renderState?.key === currentKey && renderState.status === "ready" && (
            <SvgDownloadButton
              onClick={() => {
                const svg = previewRef.current?.querySelector("svg");
                if (svg) downloadMermaidSvg(svg);
              }}
            />
          )}
          {previewButton}
        </>
      }
    >
      {body}
    </PreviewFrame>
  );
}

// What a previewed fence (mermaid here, svg in components/SvgBlock.tsx,
// plantuml in components/PlantUmlBlock.tsx) shares:
// the header with its toggle and download button, and the zoom viewer.

export function PreviewToggleButton({ isStreaming, previewVisible, onToggle, title, previewLabel }: {
  isStreaming?: boolean;
  previewVisible: boolean;
  onToggle: () => void;
  /** What a click shows: the source while the preview is visible, else the preview. */
  title: string;
  /** The label that turns the preview on, when "Preview" would not say enough. */
  previewLabel?: string;
}) {
  const { t } = useI18n();
  return (
    <button
      type="button"
      onClick={onToggle}
      disabled={isStreaming}
      title={isStreaming ? t("i18n.previewAfterStreaming") : title}
      className={["markdown-code-action", previewVisible ? "is-active" : ""].filter(Boolean).join(" ")}
    >
      {previewVisible ? t("i18n.source") : previewLabel ?? t("i18n.preview")}
    </button>
  );
}

export function SvgDownloadButton({ onClick }: { onClick: () => void }) {
  const { t } = useI18n();
  return (
    <button
      type="button"
      className="markdown-code-action"
      title={`${t("i18n.downloadFile")} (SVG)`}
      aria-label={`${t("i18n.downloadFile")} (SVG)`}
      onClick={onClick}
    >
      SVG
    </button>
  );
}

export function PreviewFrame({ lang, actions, children }: { lang: string; actions: ReactNode; children: ReactNode }) {
  return (
    <div className="markdown-code-block">
      <div className="markdown-code-header">
        <span className="markdown-code-lang">{lang}</span>
        <div className="markdown-code-actions">{actions}</div>
      </div>
      {children}
    </div>
  );
}

export function DiagramZoomDialog({ title, label, onClose, children }: {
  title: string;
  label: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const { t } = useI18n();
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [zoom, setZoom] = useState(1);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialog.showModal();

    return () => {
      document.body.style.overflow = previousOverflow;
      if (dialog.open) dialog.close();
    };
  }, []);

  return (
    <dialog
      ref={dialogRef}
      className="mermaid-zoom-dialog"
      aria-label={label}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onKeyDown={(event) => {
        if (event.key !== "Escape") return;
        event.preventDefault();
        onClose();
      }}
    >
      <div className="mermaid-zoom-layout">
        <div className="mermaid-zoom-toolbar">
          <span className="mermaid-zoom-title">{title}</span>
          <div className="mermaid-zoom-actions">
            <div className="mermaid-zoom-stepper">
              <button
                type="button"
                onClick={() => setZoom((value) => Math.max(ZOOM_MIN, value - ZOOM_STEP))}
                disabled={zoom <= ZOOM_MIN}
                title={t("i18n.zoomOut")}
                aria-label={t("i18n.zoomOut")}
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                  <path d="M5 12h14" />
                </svg>
              </button>
              <span className="mermaid-zoom-value">{Math.round(zoom * 100)}%</span>
              <button
                type="button"
                onClick={() => setZoom((value) => Math.min(ZOOM_MAX, value + ZOOM_STEP))}
                disabled={zoom >= ZOOM_MAX}
                title={t("i18n.zoomIn")}
                aria-label={t("i18n.zoomIn")}
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                  <path d="M12 5v14M5 12h14" />
                </svg>
              </button>
            </div>
            <button
              type="button"
              className="mermaid-zoom-icon-button"
              onClick={() => setZoom(1)}
              title={t("i18n.fitToWidth")}
              aria-label={t("i18n.fitToWidth")}
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5" />
              </svg>
            </button>
            <button
              type="button"
              className="mermaid-zoom-icon-button"
              onClick={onClose}
              title={t("i18n.close")}
              aria-label={t("i18n.close")}
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                <path d="M6 6l12 12M18 6 6 18" />
              </svg>
            </button>
          </div>
        </div>
        <div
          className="mermaid-zoom-viewport"
          onClick={(event) => {
            if (event.target === event.currentTarget) onClose();
          }}
        >
          <div className="mermaid-zoom-canvas" style={{ width: `${zoom * 100}%` }}>
            {children}
          </div>
        </div>
      </div>
    </dialog>
  );
}

interface CodeBlockProps {
  code: string;
  lang: string;
  headerAction?: ReactNode;
  isStreaming?: boolean;
}

// Prism's light theme uses backgroundColor, while its dark theme uses the
// background shorthand. Keep the pre background solely in customStyle so a
// theme switch cannot remove/update one and reset the other in React's diff.
const codeBlockDarkTheme = {
  ...vscDarkPlus,
  'pre[class*="language-"]': {
    ...vscDarkPlus['pre[class*="language-"]'],
  },
};
delete codeBlockDarkTheme['pre[class*="language-"]'].background;

type CodeLinesProps = Parameters<NonNullable<SyntaxHighlighterProps["renderer"]>>[0];

/**
 * A fence's lines, each a row of its number and its text (`.markdown-code-line`
 * in app/globals.css): long lines wrap, as in pi's TUI, and a wrapped line goes
 * on under its own text, never under the number. The text keeps the row's own
 * classes, which color the later lines of a token that spans several (a block
 * comment).
 */
function renderCodeLines({ rows, stylesheet, useInlineStyles }: CodeLinesProps) {
  return rows.map((row, index) => {
    const children = row.children ?? [];
    const number = children[0]?.properties?.className.includes("react-syntax-highlighter-line-number") ? children[0] : null;
    const text = {
      ...row,
      properties: { ...row.properties, className: [...(row.properties?.className ?? []), "markdown-code-line-text"] },
      children: number ? children.slice(1) : children,
    };
    return (
      <span key={index} className="markdown-code-line">
        {number && (
          <span
            className="markdown-code-line-number"
            data-line-number={index + 1}
            aria-hidden="true"
            style={number.properties?.style}
          />
        )}
        {renderSyntaxNode({ node: text, stylesheet, useInlineStyles, key: "text" })}
      </span>
    );
  });
}

/** Lines per piece of a streaming fence. */
const STREAM_CHUNK_LINES = 64;

/** A finished piece of a streaming fence: same text, so React leaves it alone. */
const FrozenCodeChunk = memo(function FrozenCodeChunk({ text }: { text: string }) {
  return <span className="markdown-code-stream-chunk is-frozen">{text}</span>;
});

/**
 * A streaming fence's text in pieces of STREAM_CHUNK_LINES lines. Each chunk
 * only the last piece changes: React rewrites one short text node instead of
 * the whole fence, and the finished pieces, laid out on their own
 * (`content-visibility`, app/globals.css), are skipped while off screen.
 */
function StreamingCodeChunks({ code }: { code: string }) {
  const pieces: string[] = [];
  let start = 0;
  let lines = 0;
  for (let index = code.indexOf("\n"); index !== -1; index = code.indexOf("\n", index + 1)) {
    lines += 1;
    if (lines === STREAM_CHUNK_LINES) {
      // The newline between pieces is the block break itself: kept in the
      // text, a copied selection would get a blank line at every piece.
      pieces.push(code.slice(start, index));
      start = index + 1;
      lines = 0;
    }
  }
  const tail = code.slice(start);
  return (
    <>
      {pieces.map((text, index) => <FrozenCodeChunk key={index} text={text} />)}
      <span className="markdown-code-stream-chunk">{tail}</span>
    </>
  );
}

/**
 * Syntax-highlighted code block with copy button.
 * Used as the "source" view for mermaid blocks and for all non-mermaid code fences.
 *
 * Memoized: parent markdown re-renders (e.g. streaming updates elsewhere in
 * the message list) must not re-run Prism tokenization on unchanged code.
 * While the owning message is still streaming, the block renders as plain
 * monospace text — highlighting a growing block re-tokenizes all of it on
 * every chunk, which is the single most expensive part of streamed rendering.
 * A finished block past this task's highlight budget (lib/highlight-queue.ts),
 * or mounted before the Prism languages have loaded (lib/prism-languages.ts),
 * renders through the same highlighter as `text` (same lines, numbers and
 * box, no tokens) until an idle slice lets it take its language.
 */
export const CodeBlock = memo(function CodeBlock({ code, lang, headerAction, isStreaming }: CodeBlockProps) {
  const { isDark } = useTheme();
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);
  // Loading starts with the first block, streaming or not, so a streamed
  // reply usually finds the languages ready when it ends.
  const languagesReady = usePrismLanguages();
  const [highlighted, setHighlighted] = useState(
    () => !isStreaming && prismLanguagesLoaded() && takeHighlightBudget(code.length),
  );

  useEffect(() => {
    if (isStreaming || highlighted || !languagesReady) return;
    return waitForHighlight(() => setHighlighted(true));
  }, [isStreaming, highlighted, languagesReady]);

  const copy = () => {
    // A refused copy is silent: no "Copied", and the rejection is handled
    // so it never surfaces as an unhandled one (lib/clipboard.ts).
    copyText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }, () => {});
  };

  return (
    <div className="markdown-code-block">
      <div className="markdown-code-header">
        <span className="markdown-code-lang">{lang || "text"}</span>
        <div className="markdown-code-actions">
          {headerAction}
          <button
            onClick={copy}
            className="markdown-code-action"
          >
            {copied ? t("i18n.copied") : t("i18n.copy")}
          </button>
        </div>
      </div>
      {isStreaming ? (
        <pre
          style={{
            margin: 0,
            padding: "11px 13px",
            fontSize: "calc(12.5px + var(--chat-font-size-offset, 0px))",
            lineHeight: 1.62,
            whiteSpace: "pre-wrap",
            overflowWrap: "anywhere",
            backgroundColor: "color-mix(in srgb, var(--bg) 92%, var(--bg-panel))",
          }}
        >
          <code style={{ fontFamily: "var(--font-mono)" }}><StreamingCodeChunks code={code} /></code>
        </pre>
      ) : (
        <SyntaxHighlighter
          language={highlighted ? lang || "text" : "text"}
          style={isDark ? codeBlockDarkTheme : vs}
          showLineNumbers
          lineNumberStyle={{ color: "var(--text-dim)", fontStyle: "normal", flexShrink: 0 }}
          renderer={renderCodeLines}
          customStyle={{
            margin: 0,
            padding: "11px 13px",
            fontSize: "calc(12.5px + var(--chat-font-size-offset, 0px))",
            lineHeight: 1.62,
            fontWeight: "var(--font-mono-weight)",
            // The light `vs` theme puts its own 1px #ddd border on <pre>; the
            // block's wrapper already draws the frame.
            border: "none",
            borderRadius: 0,
            backgroundColor: "color-mix(in srgb, var(--bg) 92%, var(--bg-panel))",
          }}
          codeTagProps={{ style: { fontFamily: "var(--font-mono)", fontWeight: "var(--font-mono-weight)" } }}
        >
          {code}
        </SyntaxHighlighter>
      )}
    </div>
  );
});
